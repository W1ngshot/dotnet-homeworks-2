﻿namespace Server.Models;

public class FightingCharacters
{
    public Character Player { get; set; } = null!;
    public Character Monster { get; set; } = null!;
}